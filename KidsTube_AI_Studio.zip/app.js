const $=id=>document.getElementById(id);
let currentScript="";
let stories=JSON.parse(localStorage.getItem("kidstube_stories")||"[]");
function showView(name){
 document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));
 $(name+"View").classList.remove("hidden");
 document.querySelectorAll(".nav").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
 const titles={home:["Hello, Creator! 👋","Ready to make something magical?"],create:["Story creator ✨","Bring your next idea to life."],library:["Your story library 🎬","All your saved adventures in one place."]};
 $("pageTitle").textContent=titles[name][0];$("pageSub").textContent=titles[name][1];
 if(name==="library")renderLibrary();
}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>showView(b.dataset.view));
["topCreate","heroCreate","libraryCreate"].forEach(id=>$(id).onclick=()=>showView("create"));
document.querySelectorAll(".quick").forEach(b=>b.onclick=()=>{showView("create");$("topic").value=b.dataset.topic;$("title").value=b.querySelector("b").textContent+" Adventure";});
function makeScript(title,topic,age,duration,language){
 const intro=`Hello, little explorers! Welcome to ${title}!`;
 const scenes=[
 ["Scene 1 — The beginning",`Narrator: ${intro}\nWe are about to discover ${topic.toLowerCase()}. Our curious friend is ready for a wonderful adventure!`],
 ["Scene 2 — A little discovery",`Character: “Wow! What can we learn today?”\nNarrator: Along the way, our friend looks, listens, and asks a clever question about ${topic.toLowerCase()}.`],
 ["Scene 3 — Let's try together",`Narrator: “Let's learn together!”\nInvite children to pause, think, count, or say the answer aloud. Celebrate every attempt: “Great thinking!”`],
 ["Scene 4 — The happy ending",`Narrator: Our adventure is complete! Remember, learning is fun when we explore together.\nCharacter: “See you next time, friends!”`]
 ];
 return `${title}\nKidsTube AI Studio • ${age} • ${duration} • ${language}\n\nVIDEO SCRIPT\n\n${scenes.map(s=>s[0]+"\n"+s[1]).join("\n\n")}\n\nEND CARD\n“Thanks for learning with us! Like the video and ask a grown-up to help you explore another adventure.”\n\nCREATOR NOTE\nThis is a starter template. Review facts, language, and age suitability before publishing.`;
}
$("storyForm").onsubmit=e=>{
 e.preventDefault();
 const title=$("title").value.trim(),topic=$("topic").value.trim();
 currentScript=makeScript(title,topic,$("age").value,$("duration").value,$("language").value);
 $("resultTitle").textContent=title;$("scriptText").textContent=currentScript;$("result").classList.remove("hidden");
};
$("copyBtn").onclick=async()=>{try{await navigator.clipboard.writeText(currentScript);$("copyBtn").textContent="Copied ✓";}catch{alert("Select the script text and copy it.");}};
$("downloadBtn").onclick=()=>{const blob=new Blob([currentScript],{type:"text/plain"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=($("title").value||"kids-story").replace(/[^a-z0-9]/gi,"-")+".txt";a.click();URL.revokeObjectURL(a.href);};
$("saveBtn").onclick=()=>{stories.unshift({title:$("title").value,topic:$("topic").value,script:currentScript,date:new Date().toLocaleDateString()});localStorage.setItem("kidstube_stories",JSON.stringify(stories));renderStats();$("saveBtn").textContent="Saved ✓";};
function renderLibrary(){const el=$("libraryList");if(!stories.length){el.innerHTML='<div class="panel"><h3>🌱 Your library is waiting</h3><p>Create a story and tap “Save story” to keep it here.</p></div>';return;}el.innerHTML=stories.map((s,i)=>`<div class="story-card"><div><h4>📘 ${escapeHtml(s.title)}</h4><small>${escapeHtml(s.date)} · ${escapeHtml(s.topic)}</small></div><button class="soft-btn" data-open="${i}">View script</button></div>`).join("");el.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>{const s=stories[+b.dataset.open];showView("create");$("title").value=s.title;$("topic").value=s.topic;currentScript=s.script;$("resultTitle").textContent=s.title;$("scriptText").textContent=s.script;$("result").classList.remove("hidden");});}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderStats(){$("storyCount").textContent=stories.length;$("sceneCount").textContent=stories.length*4;}
renderStats();showView("home");
